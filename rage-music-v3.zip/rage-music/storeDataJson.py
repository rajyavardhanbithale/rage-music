import json
import random,string

letters = string.ascii_lowercase + string.ascii_lowercase + string.ascii_letters + string.digits
randomId =  ''.join(random.choice(letters) for i in range(8))

def storeDataJSONDesktop(useremail,useragent,currenttime,versionreg):
    data = {
        randomId :{
            "userEmail" : useremail,
            "browserData":{
                "userAgent" : useragent,
                "currentTime" : currenttime
            },
            "versionReg" : versionreg
        }
        
    }

    with open("emailData.json", "a") as outfile:
        json.dump(data, outfile)

    print("[-+] Append")

def storeDataJSONMobile(username,useragent,screensize,currenttime,versionreg):
    data = {
        randomId :{
            "userName" : "name",
            "browserData":{
                "userAgent" : "ag",
                "screenSize": "size",
                "currentTime" : "time"
            },
            "versionReg" : "version"
        }
        
    }

    with open("emailData.json", "a") as outfile:
        json.dump(data, outfile)
