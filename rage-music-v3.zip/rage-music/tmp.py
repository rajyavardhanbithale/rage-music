##import encryptData
#
#
##print(encryptData.main('opl','rage','encrypt'))
#
#
#import json
#import random,string
#
#letters = string.ascii_lowercase + string.ascii_lowercase + string.ascii_letters + string.digits
#randomId =  ''.join(random.choice(letters) for i in range(8))
#
#def storeDataJSON(username,useragent,screensize,currenttime,versionred):
#    data = {
#        randomId :{
#            "userName" : "name",
#            "browserData":{
#                "userAgent" : "ag",
#                "screenSize": "size",
#                "currentTime" : "time"
#            },
#            "versionReg" : "version"
#        }
#        
#    }
#
#    with open("emailData.json", "a") as outfile:
#        json.dump(data, outfile)
#
#

dat = {
   "id":"izGwDsrQ1eQ",
   "title":"George Michael - Careless Whisper (Official Video)",
   "duration":{
      "secondsText":"301"
   },
   "viewCount":{
      "text":"969376099"
   },
   "thumbnails":[
      {
         "url":"https://i.ytimg.com/vi_webp/izGwDsrQ1eQ/default.webp",
         "width":120,
         "height":90
      },
      {
         "url":"https://i.ytimg.com/vi_webp/izGwDsrQ1eQ/mqdefault.webp",
         "width":320,
         "height":180
      },
      {
         "url":"https://i.ytimg.com/vi_webp/izGwDsrQ1eQ/hqdefault.webp",
         "width":480,
         "height":360
      },
      {
         "url":"https://i.ytimg.com/vi_webp/izGwDsrQ1eQ/sddefault.webp",
         "width":640,
         "height":480
      },
      {
         "url":"https://i.ytimg.com/vi/izGwDsrQ1eQ/hq720.jpg?sqp=-oaymwEcCK4FEIIDSEbyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLCE7S6iSodfG1T0tOxMHPz0pbbpmA",
         "width":686,
         "height":386
      }
   ],
   "description":"George Michael - Careless Whisper (Official Video)\nStream and download here: https://GeorgeMichael.lnk.to/Streaming\nListen to more Love Songs here: https://spotlight.lnk.to/LoveSongs   \nSubscribe to the George Michael YouTube channel: https://GeorgeMichael.lnk.to/YouTubeS...\n\n\nSubscribe to the George Michael YouTube channel: https://smarturl.it/GM_SUBSCRIBE\n\nWATCH LAST CHRISTMAS MUSIC VIDEO IN 4K ► https://smarturl.it/LastChristmas4K\nWATCH CARELESS WHISPER MUSIC VIDEO IN HD ► https://smarturl.it/GM_CarelessWhisperHD\nWATCH FREEDOM! '90 MUSIC VIDEO ► https://smarturl.it/Freedom90Video4K\nWATCH WAKE ME UP BEFORE YOU GO GO MUSIC VIDEO IN HD ► https://smarturl.it/WAKE_ME_UP_HD\nWATCH FAITH MUSIC VIDEO ► https://smarturl.it/YT_Faith_official\n\nFollow George Michael:\nOfficial website - http://www.georgemichael.com\nFacebook - https://www.facebook.com/georgemichael/\nTwitter - https://twitter.com/GeorgeMOfficial\nInstagram - https://www.instagram.com/georgemoffi…\n\n#GeorgeMichael #CarelessWhisper #GeorgeMichaelOfficial #Wham #GeorgeMichaelOfficialVideo #GeorgeMichaelLive #GeorgeMichaelEssentials #TikTok #Faith #LastChristmas #GeorgeMichaelCarelessWhisper #NewYearMusic #HappyNewYearMusic #NewYearPlaylist #HappyNewYear\n\n\nLyrics\nI feel so unsure\nAs I take your hand\nAnd lead you to the dance floor\nAs the music dies\nSomething in your eyes\nCalls to mind a silver screen\nAnd all its sad goodbyes\n\nI'm never gonna dance again\nGuilty feet have got no rhythm\nThough it's easy to pretend\nI know you're not a fool\nI should've known better than to cheat a friend\nAnd waste the chance that I've been given\nSo I'm never gonna dance again\nThe way I danced with you\n\nTime can never mend\nThe careless whispers of a good friend\nTo the heart and mind\nIgnorance is kind\nThere's no comfort in the truth\nPain is all you'll find\n\nI'm never gonna dance again\nGuilty feet have got no rhythm\nThough it's easy to pretend\nI know you're not a fool\nI should've known better than to cheat a friend\nAnd waste the chance that I've been given\nSo I'm never gonna dance again\nThe way I danced with you\n\nTonight the music seems so loud\nI wish that we could lose this crowd\nMaybe it's better this way\nWe'd hurt each other with the things we want to say\nWe could have been so good together\nWe could have lived this dance forever\nBut now who's gonna dance with me\nPlease stay\n\nI'm never gonna dance again\nGuilty feet have got no rhythm\nThough it's easy to pretend\nI know you're not a fool\nI should've known better than to cheat a friend\nAnd waste the chance that I've been given\nSo I'm never gonna dance again\nThe way I danced with you\n\nNow that you're gone\nNow that you're gone\nNow that you're gone\nWas what I did so wrong\nSo wrong that you had to leave me alone?",
   "channel":{
      "name":"georgemichaelVEVO",
      "id":"UC7X_qC_rgc3s04Aw1t5DSHg",
      "link":"https://www.youtube.com/channel/UC7X_qC_rgc3s04Aw1t5DSHg"
   },
   "allowRatings":True,
   "averageRating":"None",
   "keywords":[
      "George Michael Careless Whisper Official video",
      "George Michael Careless Whisper",
      "George Michael Official",
      "George Michael Careless Whisper Lyrics",
      "George Michael Careless Whisper Official",
      "official video",
      "George Michael Careless Whisper tik tok",
      "George Michael Lyrics",
      "Different Corner",
      "careless whisper tiktok",
      "love songs",
      "valentines day",
      "valentines day playlist",
      "love songs playlist",
      "valentines day music",
      "new year music",
      "happy new year music"
   ],
   "isLiveContent":False,
   "publishDate":"2009-10-25",
   "uploadDate":"2009-10-25",
   "isFamilySafe":True,
   "category":"Music",
   "isLiveNow":False,
   "link":"https://www.youtube.com/watch?v=izGwDsrQ1eQ",
   "streamingData":{
      "expiresInSeconds":"21540",
      "formats":[
         {
            "itag":17,
            "url":"https://rr2---sn-gwpa-cive.googlevideo.com/videoplayback?expire=1673474248&ei=aNy-Y76qKaOj3LUPn5ebwAI&ip=49.43.40.249&id=o-ACJVtrLBkCUx8brSgDFuAw58UxfKxs-D2E1UXKmFWQb_&itag=17&source=youtube&requiressl=yes&mh=Bh&mm=31%2C29&mn=sn-gwpa-cive%2Csn-gwpa-qxak&ms=au%2Crdu&mv=m&mvi=2&pl=22&gcr=in&initcwndbps=160000&vprv=1&mime=video%2F3gpp&gir=yes&clen=3034513&dur=300.791&lmt=1637107906967479&mt=1673452159&fvip=3&fexp=24007246&c=ANDROID&txp=5511222&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cgcr%2Cvprv%2Cmime%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRAIgPUiVvmfMtpOQ-uxJIiX3oq76i5gDh3L-Pf7OMEPxOs8CIBoskRRr7IHpOonECO91q933KIlfjt0_SpHHEy4k7vpq&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIgIoRCe7Yk5uS4wvWplcXjGIsLkVXRAruEKmdzCsgneqQCIQCeSfA8p19j84KVfEczhxfqMywpZkJWwNwzEIWM1yvBfw%3D%3D",
            "mimeType":"video/3gpp; codecs=\"mp4v.20.3, mp4a.40.2\"",
            "bitrate":80748,
            "width":176,
            "height":144,
            "lastModified":"1637107906967479",
            "contentLength":"3034513",
            "quality":"small",
            "fps":6,
            "qualityLabel":"144p",
            "projectionType":"RECTANGULAR",
            "averageBitrate":80707,
            "audioQuality":"AUDIO_QUALITY_LOW",
            "approxDurationMs":"300791",
            "audioSampleRate":"22050",
            "audioChannels":1
         },
         {
            "itag":18,
            "url":"https://rr2---sn-gwpa-cive.googlevideo.com/videoplayback?expire=1673474248&ei=aNy-Y76qKaOj3LUPn5ebwAI&ip=49.43.40.249&id=o-ACJVtrLBkCUx8brSgDFuAw58UxfKxs-D2E1UXKmFWQb_&itag=18&source=youtube&requiressl=yes&mh=Bh&mm=31%2C29&mn=sn-gwpa-cive%2Csn-gwpa-qxak&ms=au%2Crdu&mv=m&mvi=2&pl=22&gcr=in&initcwndbps=160000&vprv=1&mime=video%2Fmp4&cnr=14&ratebypass=yes&dur=300.744&lmt=1665418755368926&mt=1673452159&fvip=3&fexp=24007246&c=ANDROID&txp=5538434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cgcr%2Cvprv%2Cmime%2Ccnr%2Cratebypass%2Cdur%2Clmt&sig=AOq0QJ8wRQIgEFa11Jbd9NXEEBrszF2ILc4-fDtsw53NGQ3_1L2rfiUCIQCOsH59J5R90QQ7qXLVIxCnUoX-cZFMEr8HphGmhpnm9A%3D%3D&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIgIoRCe7Yk5uS4wvWplcXjGIsLkVXRAruEKmdzCsgneqQCIQCeSfA8p19j84KVfEczhxfqMywpZkJWwNwzEIWM1yvBfw%3D%3D",
            "mimeType":"video/mp4; codecs=\"avc1.42001E, mp4a.40.2\"",
            "bitrate":272484,
            "width":590,
            "height":360,
            "lastModified":"1665418755368926",
            "quality":"medium",
            "fps":25,
            "qualityLabel":"360p",
            "projectionType":"RECTANGULAR",
            "audioQuality":"AUDIO_QUALITY_LOW",
            "approxDurationMs":"300744",
            "audioSampleRate":"44100",
            "audioChannels":2
         },
         {
            "itag":22,
            "url":"https://rr2---sn-gwpa-cive.googlevideo.com/videoplayback?expire=1673474248&ei=aNy-Y76qKaOj3LUPn5ebwAI&ip=49.43.40.249&id=o-ACJVtrLBkCUx8brSgDFuAw58UxfKxs-D2E1UXKmFWQb_&itag=22&source=youtube&requiressl=yes&mh=Bh&mm=31%2C29&mn=sn-gwpa-cive%2Csn-gwpa-qxak&ms=au%2Crdu&mv=m&mvi=2&pl=22&gcr=in&initcwndbps=160000&vprv=1&mime=video%2Fmp4&ratebypass=yes&dur=300.744&lmt=1637198456290373&mt=1673452159&fvip=3&fexp=24007246&c=ANDROID&txp=5532434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cgcr%2Cvprv%2Cmime%2Cratebypass%2Cdur%2Clmt&sig=AOq0QJ8wRQIgF0bfM76ksZUlVCJAXO2Vk0uJQFR3svCR70Jc2UOJXYcCIQC7fCB1VLfO5r2jjeztftLCuePPjZrphwG6nDh0yMKfxQ%3D%3D&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIgIoRCe7Yk5uS4wvWplcXjGIsLkVXRAruEKmdzCsgneqQCIQCeSfA8p19j84KVfEczhxfqMywpZkJWwNwzEIWM1yvBfw%3D%3D",
            "mimeType":"video/mp4; codecs=\"avc1.64001F, mp4a.40.2\"",
            "bitrate":1499686,
            "width":1178,
            "height":720,
            "lastModified":"1637198456290373",
            "quality":"hd720",
            "fps":25,
            "qualityLabel":"720p",
            "projectionType":"RECTANGULAR",
            "audioQuality":"AUDIO_QUALITY_MEDIUM",
            "approxDurationMs":"300744",
            "audioSampleRate":"44100",
            "audioChannels":2
         }
      ],
      "adaptiveFormats":[
         {
            "itag":137,
            "url":"https://rr2---sn-gwpa-cive.googlevideo.com/videoplayback?expire=1673474248&ei=aNy-Y76qKaOj3LUPn5ebwAI&ip=49.43.40.249&id=o-ACJVtrLBkCUx8brSgDFuAw58UxfKxs-D2E1UXKmFWQb_&itag=137&source=youtube&requiressl=yes&mh=Bh&mm=31%2C29&mn=sn-gwpa-cive%2Csn-gwpa-qxak&ms=au%2Crdu&mv=m&mvi=2&pl=22&gcr=in&initcwndbps=160000&vprv=1&mime=video%2Fmp4&gir=yes&clen=62350189&dur=300.680&lmt=1637209245010404&mt=1673452159&fvip=3&keepalive=yes&fexp=24007246&c=ANDROID&txp=5535434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cgcr%2Cvprv%2Cmime%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRQIhAPhdYE-JIGLsgb29D2iKUKkJbYxqH4mHn78J12NW99mfAiBvcxyG9zmAdmc-iSMsv-yVXSLrZxkMPWS2nd2qMdh0eA%3D%3D&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIgIoRCe7Yk5uS4wvWplcXjGIsLkVXRAruEKmdzCsgneqQCIQCeSfA8p19j84KVfEczhxfqMywpZkJWwNwzEIWM1yvBfw%3D%3D",
            "mimeType":"video/mp4; codecs=\"avc1.640028\"",
            "bitrate":3638326,
            "width":1768,
            "height":1080,
            "initRange":{
               "start":"0",
               "end":"742"
            },
            "indexRange":{
               "start":"743",
               "end":"1482"
            },
            "lastModified":"1637209245010404",
            "contentLength":"62350189",
            "quality":"hd1080",
            "fps":25,
            "qualityLabel":"1080p",
            "projectionType":"RECTANGULAR",
            "averageBitrate":1658911,
            "approxDurationMs":"300680"
         },
         {
            "itag":248,
            "url":"https://rr2---sn-gwpa-cive.googlevideo.com/videoplayback?expire=1673474248&ei=aNy-Y76qKaOj3LUPn5ebwAI&ip=49.43.40.249&id=o-ACJVtrLBkCUx8brSgDFuAw58UxfKxs-D2E1UXKmFWQb_&itag=248&source=youtube&requiressl=yes&mh=Bh&mm=31%2C29&mn=sn-gwpa-cive%2Csn-gwpa-qxak&ms=au%2Crdu&mv=m&mvi=2&pl=22&gcr=in&initcwndbps=160000&vprv=1&mime=video%2Fwebm&gir=yes&clen=49067423&dur=300.680&lmt=1665686711253753&mt=1673452159&fvip=3&keepalive=yes&fexp=24007246&c=ANDROID&txp=5535434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cgcr%2Cvprv%2Cmime%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRAIgeP0ybjhypounpmFjCuuSbd9hkTEKjdw8jIjE6wFwSZsCIDDoNb7VqFN_Sh0HhzDgdDHIwJxvIU-CC-Gas6K4zPv0&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIgIoRCe7Yk5uS4wvWplcXjGIsLkVXRAruEKmdzCsgneqQCIQCeSfA8p19j84KVfEczhxfqMywpZkJWwNwzEIWM1yvBfw%3D%3D",
            "mimeType":"video/webm; codecs=\"vp9\"",
            "bitrate":2519228,
            "width":1768,
            "height":1080,
            "initRange":{
               "start":"0",
               "end":"219"
            },
            "indexRange":{
               "start":"220",
               "end":"1215"
            },
            "lastModified":"1665686711253753",
            "contentLength":"49067423",
            "quality":"hd1080",
            "fps":25,
            "qualityLabel":"1080p",
            "projectionType":"RECTANGULAR",
            "averageBitrate":1305505,
            "colorInfo":{
               "primaries":"COLOR_PRIMARIES_BT709",
               "transferCharacteristics":"COLOR_TRANSFER_CHARACTERISTICS_BT709",
               "matrixCoefficients":"COLOR_MATRIX_COEFFICIENTS_BT709"
            },
            "approxDurationMs":"300680"
         },
         {
            "itag":399,
            "url":"https://rr2---sn-gwpa-cive.googlevideo.com/videoplayback?expire=1673474248&ei=aNy-Y76qKaOj3LUPn5ebwAI&ip=49.43.40.249&id=o-ACJVtrLBkCUx8brSgDFuAw58UxfKxs-D2E1UXKmFWQb_&itag=399&source=youtube&requiressl=yes&mh=Bh&mm=31%2C29&mn=sn-gwpa-cive%2Csn-gwpa-qxak&ms=au%2Crdu&mv=m&mvi=2&pl=22&gcr=in&initcwndbps=160000&vprv=1&mime=video%2Fmp4&gir=yes&clen=39730390&dur=300.680&lmt=1637237051419801&mt=1673452159&fvip=3&keepalive=yes&fexp=24007246&c=ANDROID&txp=5532434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cgcr%2Cvprv%2Cmime%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRQIgCaaIgygvu3KZcWFdR7ksFcBsgxwVEt0-ruKc4ei03dACIQCECh2fhJIvmQNPSQjSXnys7wLNTXVgYM2oSfabV9LMog%3D%3D&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIgIoRCe7Yk5uS4wvWplcXjGIsLkVXRAruEKmdzCsgneqQCIQCeSfA8p19j84KVfEczhxfqMywpZkJWwNwzEIWM1yvBfw%3D%3D",
            "mimeType":"video/mp4; codecs=\"av01.0.08M.08\"",
            "bitrate":1959312,
            "width":1768,
            "height":1080,
            "initRange":{
               "start":"0",
               "end":"699"
            },
            "indexRange":{
               "start":"700",
               "end":"1439"
            },
            "lastModified":"1637237051419801",
            "contentLength":"39730390",
            "quality":"hd1080",
            "fps":25,
            "qualityLabel":"1080p",
            "projectionType":"RECTANGULAR",
            "averageBitrate":1057081,
            "colorInfo":{
               "primaries":"COLOR_PRIMARIES_BT709",
               "transferCharacteristics":"COLOR_TRANSFER_CHARACTERISTICS_BT709",
               "matrixCoefficients":"COLOR_MATRIX_COEFFICIENTS_BT709"
            },
            "approxDurationMs":"300680"
         },
         {
            "itag":136,
            "url":"https://rr2---sn-gwpa-cive.googlevideo.com/videoplayback?expire=1673474248&ei=aNy-Y76qKaOj3LUPn5ebwAI&ip=49.43.40.249&id=o-ACJVtrLBkCUx8brSgDFuAw58UxfKxs-D2E1UXKmFWQb_&itag=136&source=youtube&requiressl=yes&mh=Bh&mm=31%2C29&mn=sn-gwpa-cive%2Csn-gwpa-qxak&ms=au%2Crdu&mv=m&mvi=2&pl=22&gcr=in&initcwndbps=160000&vprv=1&mime=video%2Fmp4&gir=yes&clen=15256222&dur=300.680&lmt=1637209250740517&mt=1673452159&fvip=3&keepalive=yes&fexp=24007246&c=ANDROID&txp=5535434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cgcr%2Cvprv%2Cmime%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRQIgTcWBL7LO4oRIDFsePiZz08BDluY-vk-rFs5n6Q6iBacCIQDg6q-GeJKPjMAGKEAAg-WK_OSdo-8GdAhy3gd2F2hbaA%3D%3D&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIgIoRCe7Yk5uS4wvWplcXjGIsLkVXRAruEKmdzCsgneqQCIQCeSfA8p19j84KVfEczhxfqMywpZkJWwNwzEIWM1yvBfw%3D%3D",
            "mimeType":"video/mp4; codecs=\"avc1.4d401f\"",
            "bitrate":766234,
            "width":1178,
            "height":720,
            "initRange":{
               "start":"0",
               "end":"740"
            },
            "indexRange":{
               "start":"741",
               "end":"1480"
            },
            "lastModified":"1637209250740517",
            "contentLength":"15256222",
            "quality":"hd720",
            "fps":25,
            "qualityLabel":"720p",
            "projectionType":"RECTANGULAR",
            "averageBitrate":405912,
            "approxDurationMs":"300680"
         },
         {
            "itag":247,
            "url":"https://rr2---sn-gwpa-cive.googlevideo.com/videoplayback?expire=1673474248&ei=aNy-Y76qKaOj3LUPn5ebwAI&ip=49.43.40.249&id=o-ACJVtrLBkCUx8brSgDFuAw58UxfKxs-D2E1UXKmFWQb_&itag=247&source=youtube&requiressl=yes&mh=Bh&mm=31%2C29&mn=sn-gwpa-cive%2Csn-gwpa-qxak&ms=au%2Crdu&mv=m&mvi=2&pl=22&gcr=in&initcwndbps=160000&vprv=1&mime=video%2Fwebm&gir=yes&clen=15147354&dur=300.680&lmt=1665688170546397&mt=1673452159&fvip=3&keepalive=yes&fexp=24007246&c=ANDROID&txp=5535434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cgcr%2Cvprv%2Cmime%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRQIgCn65gzMXv_amP84Ry1A75g1liu-eTtjTzv5R6_JM_NcCIQDjT-w2Hm3bfJ1YLLz1s-Qej6nIpr5f4a1T8a4kqfr22g%3D%3D&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIgIoRCe7Yk5uS4wvWplcXjGIsLkVXRAruEKmdzCsgneqQCIQCeSfA8p19j84KVfEczhxfqMywpZkJWwNwzEIWM1yvBfw%3D%3D",
            "mimeType":"video/webm; codecs=\"vp9\"",
            "bitrate":1119822,
            "width":1178,
            "height":720,
            "initRange":{
               "start":"0",
               "end":"219"
            },
            "indexRange":{
               "start":"220",
               "end":"1179"
            },
            "lastModified":"1665688170546397",
            "contentLength":"15147354",
            "quality":"hd720",
            "fps":25,
            "qualityLabel":"720p",
            "projectionType":"RECTANGULAR",
            "averageBitrate":403015,
            "colorInfo":{
               "primaries":"COLOR_PRIMARIES_BT709",
               "transferCharacteristics":"COLOR_TRANSFER_CHARACTERISTICS_BT709",
               "matrixCoefficients":"COLOR_MATRIX_COEFFICIENTS_BT709"
            },
            "approxDurationMs":"300680"
         },
         {
            "itag":398,
            "url":"https://rr2---sn-gwpa-cive.googlevideo.com/videoplayback?expire=1673474248&ei=aNy-Y76qKaOj3LUPn5ebwAI&ip=49.43.40.249&id=o-ACJVtrLBkCUx8brSgDFuAw58UxfKxs-D2E1UXKmFWQb_&itag=398&source=youtube&requiressl=yes&mh=Bh&mm=31%2C29&mn=sn-gwpa-cive%2Csn-gwpa-qxak&ms=au%2Crdu&mv=m&mvi=2&pl=22&gcr=in&initcwndbps=160000&vprv=1&mime=video%2Fmp4&gir=yes&clen=21416017&dur=300.680&lmt=1637221997967284&mt=1673452159&fvip=3&keepalive=yes&fexp=24007246&c=ANDROID&txp=5532434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cgcr%2Cvprv%2Cmime%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRQIhAIjrKCMCpaHUEurSQ4cf1mEM_N69VdTXB_RUZJ8YmqEEAiBJn14OKuIUt7mGC1THu70YjcqbP2bYkwLoKlOE2qs5jQ%3D%3D&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIgIoRCe7Yk5uS4wvWplcXjGIsLkVXRAruEKmdzCsgneqQCIQCeSfA8p19j84KVfEczhxfqMywpZkJWwNwzEIWM1yvBfw%3D%3D",
            "mimeType":"video/mp4; codecs=\"av01.0.05M.08\"",
            "bitrate":1109400,
            "width":1178,
            "height":720,
            "initRange":{
               "start":"0",
               "end":"699"
            },
            "indexRange":{
               "start":"700",
               "end":"1439"
            },
            "lastModified":"1637221997967284",
            "contentLength":"21416017",
            "quality":"hd720",
            "fps":25,
            "qualityLabel":"720p",
            "projectionType":"RECTANGULAR",
            "averageBitrate":569802,
            "colorInfo":{
               "primaries":"COLOR_PRIMARIES_BT709",
               "transferCharacteristics":"COLOR_TRANSFER_CHARACTERISTICS_BT709",
               "matrixCoefficients":"COLOR_MATRIX_COEFFICIENTS_BT709"
            },
            "approxDurationMs":"300680"
         },
         {
            "itag":135,
            "url":"https://rr2---sn-gwpa-cive.googlevideo.com/videoplayback?expire=1673474248&ei=aNy-Y76qKaOj3LUPn5ebwAI&ip=49.43.40.249&id=o-ACJVtrLBkCUx8brSgDFuAw58UxfKxs-D2E1UXKmFWQb_&itag=135&source=youtube&requiressl=yes&mh=Bh&mm=31%2C29&mn=sn-gwpa-cive%2Csn-gwpa-qxak&ms=au%2Crdu&mv=m&mvi=2&pl=22&gcr=in&initcwndbps=160000&vprv=1&mime=video%2Fmp4&gir=yes&clen=8153431&dur=300.680&lmt=1637209250795288&mt=1673452159&fvip=3&keepalive=yes&fexp=24007246&c=ANDROID&txp=5535434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cgcr%2Cvprv%2Cmime%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRgIhAO-yvV-bgHJtf_1wgGzm1gTk6yGGEWeTj3Q8YPTCIPXhAiEAwSXDl-I56Tbx-KCaqJQLiK94F4U_bF25-ej1myIzzRc%3D&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIgIoRCe7Yk5uS4wvWplcXjGIsLkVXRAruEKmdzCsgneqQCIQCeSfA8p19j84KVfEczhxfqMywpZkJWwNwzEIWM1yvBfw%3D%3D",
            "mimeType":"video/mp4; codecs=\"avc1.4d401e\"",
            "bitrate":411210,
            "width":786,
            "height":480,
            "initRange":{
               "start":"0",
               "end":"740"
            },
            "indexRange":{
               "start":"741",
               "end":"1480"
            },
            "lastModified":"1637209250795288",
            "contentLength":"8153431",
            "quality":"large",
            "fps":25,
            "qualityLabel":"480p",
            "projectionType":"RECTANGULAR",
            "averageBitrate":216933,
            "approxDurationMs":"300680"
         },
         {
            "itag":244,
            "url":"https://rr2---sn-gwpa-cive.googlevideo.com/videoplayback?expire=1673474248&ei=aNy-Y76qKaOj3LUPn5ebwAI&ip=49.43.40.249&id=o-ACJVtrLBkCUx8brSgDFuAw58UxfKxs-D2E1UXKmFWQb_&itag=244&source=youtube&requiressl=yes&mh=Bh&mm=31%2C29&mn=sn-gwpa-cive%2Csn-gwpa-qxak&ms=au%2Crdu&mv=m&mvi=2&pl=22&gcr=in&initcwndbps=160000&vprv=1&mime=video%2Fwebm&gir=yes&clen=8524500&dur=300.680&lmt=1665687595168773&mt=1673452159&fvip=3&keepalive=yes&fexp=24007246&c=ANDROID&txp=5535434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cgcr%2Cvprv%2Cmime%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRQIgKmYOPnSKJCFlKRRn3APH6RtnPAPy5iekxFfPieoVobkCIQCsiJitJgsxWo5RqF6eAhhhzK95l7smRO8ZsC_lw9Jx9g%3D%3D&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIgIoRCe7Yk5uS4wvWplcXjGIsLkVXRAruEKmdzCsgneqQCIQCeSfA8p19j84KVfEczhxfqMywpZkJWwNwzEIWM1yvBfw%3D%3D",
            "mimeType":"video/webm; codecs=\"vp9\"",
            "bitrate":547044,
            "width":786,
            "height":480,
            "initRange":{
               "start":"0",
               "end":"219"
            },
            "indexRange":{
               "start":"220",
               "end":"1179"
            },
            "lastModified":"1665687595168773",
            "contentLength":"8524500",
            "quality":"large",
            "fps":25,
            "qualityLabel":"480p",
            "projectionType":"RECTANGULAR",
            "averageBitrate":226805,
            "colorInfo":{
               "primaries":"COLOR_PRIMARIES_BT709",
               "transferCharacteristics":"COLOR_TRANSFER_CHARACTERISTICS_BT709",
               "matrixCoefficients":"COLOR_MATRIX_COEFFICIENTS_BT709"
            },
            "approxDurationMs":"300680"
         },
         {
            "itag":397,
            "url":"https://rr2---sn-gwpa-cive.googlevideo.com/videoplayback?expire=1673474248&ei=aNy-Y76qKaOj3LUPn5ebwAI&ip=49.43.40.249&id=o-ACJVtrLBkCUx8brSgDFuAw58UxfKxs-D2E1UXKmFWQb_&itag=397&source=youtube&requiressl=yes&mh=Bh&mm=31%2C29&mn=sn-gwpa-cive%2Csn-gwpa-qxak&ms=au%2Crdu&mv=m&mvi=2&pl=22&gcr=in&initcwndbps=160000&vprv=1&mime=video%2Fmp4&gir=yes&clen=10679986&dur=300.680&lmt=1637222477728876&mt=1673452159&fvip=3&keepalive=yes&fexp=24007246&c=ANDROID&txp=5532434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cgcr%2Cvprv%2Cmime%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRQIhAKel8ycd8qoSvFIUPhHBxzw7e14vAgf067i9e95YKAM3AiAiPc02N8x0A8M4ZUiS145dJlTtJGQpAjue1UtaK-iIqg%3D%3D&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIgIoRCe7Yk5uS4wvWplcXjGIsLkVXRAruEKmdzCsgneqQCIQCeSfA8p19j84KVfEczhxfqMywpZkJWwNwzEIWM1yvBfw%3D%3D",
            "mimeType":"video/mp4; codecs=\"av01.0.04M.08\"",
            "bitrate":546595,
            "width":786,
            "height":480,
            "initRange":{
               "start":"0",
               "end":"699"
            },
            "indexRange":{
               "start":"700",
               "end":"1439"
            },
            "lastModified":"1637222477728876",
            "contentLength":"10679986",
            "quality":"large",
            "fps":25,
            "qualityLabel":"480p",
            "projectionType":"RECTANGULAR",
            "averageBitrate":284155,
            "colorInfo":{
               "primaries":"COLOR_PRIMARIES_BT709",
               "transferCharacteristics":"COLOR_TRANSFER_CHARACTERISTICS_BT709",
               "matrixCoefficients":"COLOR_MATRIX_COEFFICIENTS_BT709"
            },
            "approxDurationMs":"300680"
         },
         {
            "itag":134,
            "url":"https://rr2---sn-gwpa-cive.googlevideo.com/videoplayback?expire=1673474248&ei=aNy-Y76qKaOj3LUPn5ebwAI&ip=49.43.40.249&id=o-ACJVtrLBkCUx8brSgDFuAw58UxfKxs-D2E1UXKmFWQb_&itag=134&source=youtube&requiressl=yes&mh=Bh&mm=31%2C29&mn=sn-gwpa-cive%2Csn-gwpa-qxak&ms=au%2Crdu&mv=m&mvi=2&pl=22&gcr=in&initcwndbps=160000&vprv=1&mime=video%2Fmp4&gir=yes&clen=5389591&dur=300.680&lmt=1637209250682648&mt=1673452159&fvip=3&keepalive=yes&fexp=24007246&c=ANDROID&txp=5535434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cgcr%2Cvprv%2Cmime%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRAIgIHASXiUo3I3ZbHYNiinC-IpaocWdD7WG7_w3PRRVtMACIAZy7yRPg_5PMWgkAJ_Gj-yeIPm7wZran2fxTOHgJfDc&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIgIoRCe7Yk5uS4wvWplcXjGIsLkVXRAruEKmdzCsgneqQCIQCeSfA8p19j84KVfEczhxfqMywpZkJWwNwzEIWM1yvBfw%3D%3D",
            "mimeType":"video/mp4; codecs=\"avc1.4d401e\"",
            "bitrate":277471,
            "width":590,
            "height":360,
            "initRange":{
               "start":"0",
               "end":"740"
            },
            "indexRange":{
               "start":"741",
               "end":"1480"
            },
            "lastModified":"1637209250682648",
            "contentLength":"5389591",
            "quality":"medium",
            "fps":25,
            "qualityLabel":"360p",
            "projectionType":"RECTANGULAR",
            "averageBitrate":143397,
            "highReplication":True,
            "approxDurationMs":"300680"
         },
         {
            "itag":243,
            "url":"https://rr2---sn-gwpa-cive.googlevideo.com/videoplayback?expire=1673474248&ei=aNy-Y76qKaOj3LUPn5ebwAI&ip=49.43.40.249&id=o-ACJVtrLBkCUx8brSgDFuAw58UxfKxs-D2E1UXKmFWQb_&itag=243&source=youtube&requiressl=yes&mh=Bh&mm=31%2C29&mn=sn-gwpa-cive%2Csn-gwpa-qxak&ms=au%2Crdu&mv=m&mvi=2&pl=22&gcr=in&initcwndbps=160000&vprv=1&mime=video%2Fwebm&gir=yes&clen=5967945&dur=300.680&lmt=1665687805847527&mt=1673452159&fvip=3&keepalive=yes&fexp=24007246&c=ANDROID&txp=5535434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cgcr%2Cvprv%2Cmime%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRQIhAPDeyyeJ6W6LzYBqmNsb5XK90RYf3y__IhXDoUfrpl-BAiAEx9thEW2FFynJ-kU_JylMeABs8u79CXHiHcqdtWfPBg%3D%3D&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIgIoRCe7Yk5uS4wvWplcXjGIsLkVXRAruEKmdzCsgneqQCIQCeSfA8p19j84KVfEczhxfqMywpZkJWwNwzEIWM1yvBfw%3D%3D",
            "mimeType":"video/webm; codecs=\"vp9\"",
            "bitrate":334832,
            "width":590,
            "height":360,
            "initRange":{
               "start":"0",
               "end":"219"
            },
            "indexRange":{
               "start":"220",
               "end":"1179"
            },
            "lastModified":"1665687805847527",
            "contentLength":"5967945",
            "quality":"medium",
            "fps":25,
            "qualityLabel":"360p",
            "projectionType":"RECTANGULAR",
            "averageBitrate":158785,
            "colorInfo":{
               "primaries":"COLOR_PRIMARIES_BT709",
               "transferCharacteristics":"COLOR_TRANSFER_CHARACTERISTICS_BT709",
               "matrixCoefficients":"COLOR_MATRIX_COEFFICIENTS_BT709"
            },
            "approxDurationMs":"300680"
         },
         {
            "itag":396,
            "url":"https://rr2---sn-gwpa-cive.googlevideo.com/videoplayback?expire=1673474248&ei=aNy-Y76qKaOj3LUPn5ebwAI&ip=49.43.40.249&id=o-ACJVtrLBkCUx8brSgDFuAw58UxfKxs-D2E1UXKmFWQb_&itag=396&source=youtube&requiressl=yes&mh=Bh&mm=31%2C29&mn=sn-gwpa-cive%2Csn-gwpa-qxak&ms=au%2Crdu&mv=m&mvi=2&pl=22&gcr=in&initcwndbps=160000&vprv=1&mime=video%2Fmp4&gir=yes&clen=6212428&dur=300.680&lmt=1637221812452403&mt=1673452159&fvip=3&keepalive=yes&fexp=24007246&c=ANDROID&txp=5532434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cgcr%2Cvprv%2Cmime%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRgIhAJoxlJ1Ul2Ep9bFZU8Hdfc1nWxFSzWQaXFx38YDfCSi_AiEA_gx8iGfXbMrZ-Z_kd6Io97XAG4VWSlZs7pijQlR-5sA%3D&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIgIoRCe7Yk5uS4wvWplcXjGIsLkVXRAruEKmdzCsgneqQCIQCeSfA8p19j84KVfEczhxfqMywpZkJWwNwzEIWM1yvBfw%3D%3D",
            "mimeType":"video/mp4; codecs=\"av01.0.01M.08\"",
            "bitrate":285582,
            "width":590,
            "height":360,
            "initRange":{
               "start":"0",
               "end":"699"
            },
            "indexRange":{
               "start":"700",
               "end":"1439"
            },
            "lastModified":"1637221812452403",
            "contentLength":"6212428",
            "quality":"medium",
            "fps":25,
            "qualityLabel":"360p",
            "projectionType":"RECTANGULAR",
            "averageBitrate":165290,
            "colorInfo":{
               "primaries":"COLOR_PRIMARIES_BT709",
               "transferCharacteristics":"COLOR_TRANSFER_CHARACTERISTICS_BT709",
               "matrixCoefficients":"COLOR_MATRIX_COEFFICIENTS_BT709"
            },
            "approxDurationMs":"300680"
         },
         {
            "itag":133,
            "url":"https://rr2---sn-gwpa-cive.googlevideo.com/videoplayback?expire=1673474248&ei=aNy-Y76qKaOj3LUPn5ebwAI&ip=49.43.40.249&id=o-ACJVtrLBkCUx8brSgDFuAw58UxfKxs-D2E1UXKmFWQb_&itag=133&source=youtube&requiressl=yes&mh=Bh&mm=31%2C29&mn=sn-gwpa-cive%2Csn-gwpa-qxak&ms=au%2Crdu&mv=m&mvi=2&pl=22&gcr=in&initcwndbps=160000&vprv=1&mime=video%2Fmp4&gir=yes&clen=2981070&dur=300.680&lmt=1637209251012133&mt=1673452159&fvip=3&keepalive=yes&fexp=24007246&c=ANDROID&txp=5535434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cgcr%2Cvprv%2Cmime%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRQIgNcWt8MQJ5fEJO5ld2SZeYxy6y35wDTkpVKv5bDnrjDoCIQD7nZyayqr-KPbut7DAhUAitqyjYlKkL9dYK8BwQSs0hg%3D%3D&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIgIoRCe7Yk5uS4wvWplcXjGIsLkVXRAruEKmdzCsgneqQCIQCeSfA8p19j84KVfEczhxfqMywpZkJWwNwzEIWM1yvBfw%3D%3D",
            "mimeType":"video/mp4; codecs=\"avc1.4d400d\"",
            "bitrate":159870,
            "width":392,
            "height":240,
            "initRange":{
               "start":"0",
               "end":"739"
            },
            "indexRange":{
               "start":"740",
               "end":"1479"
            },
            "lastModified":"1637209251012133",
            "contentLength":"2981070",
            "quality":"small",
            "fps":25,
            "qualityLabel":"240p",
            "projectionType":"RECTANGULAR",
            "averageBitrate":79315,
            "approxDurationMs":"300680"
         },
         {
            "itag":242,
            "url":"https://rr2---sn-gwpa-cive.googlevideo.com/videoplayback?expire=1673474248&ei=aNy-Y76qKaOj3LUPn5ebwAI&ip=49.43.40.249&id=o-ACJVtrLBkCUx8brSgDFuAw58UxfKxs-D2E1UXKmFWQb_&itag=242&source=youtube&requiressl=yes&mh=Bh&mm=31%2C29&mn=sn-gwpa-cive%2Csn-gwpa-qxak&ms=au%2Crdu&mv=m&mvi=2&pl=22&gcr=in&initcwndbps=160000&vprv=1&mime=video%2Fwebm&gir=yes&clen=3560726&dur=300.680&lmt=1665687590425886&mt=1673452159&fvip=3&keepalive=yes&fexp=24007246&c=ANDROID&txp=5535434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cgcr%2Cvprv%2Cmime%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRgIhAJpZxN1_MIVASMnEFLvJdt9I9sDoY-FZCc5bLYtp5kzzAiEA8Vw7idCEgqGD6csk10AsW8RLtnbrleno68C8pd4Ev6k%3D&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIgIoRCe7Yk5uS4wvWplcXjGIsLkVXRAruEKmdzCsgneqQCIQCeSfA8p19j84KVfEczhxfqMywpZkJWwNwzEIWM1yvBfw%3D%3D",
            "mimeType":"video/webm; codecs=\"vp9\"",
            "bitrate":204006,
            "width":392,
            "height":240,
            "initRange":{
               "start":"0",
               "end":"218"
            },
            "indexRange":{
               "start":"219",
               "end":"1176"
            },
            "lastModified":"1665687590425886",
            "contentLength":"3560726",
            "quality":"small",
            "fps":25,
            "qualityLabel":"240p",
            "projectionType":"RECTANGULAR",
            "averageBitrate":94737,
            "colorInfo":{
               "primaries":"COLOR_PRIMARIES_BT709",
               "transferCharacteristics":"COLOR_TRANSFER_CHARACTERISTICS_BT709",
               "matrixCoefficients":"COLOR_MATRIX_COEFFICIENTS_BT709"
            },
            "approxDurationMs":"300680"
         },
         {
            "itag":395,
            "url":"https://rr2---sn-gwpa-cive.googlevideo.com/videoplayback?expire=1673474248&ei=aNy-Y76qKaOj3LUPn5ebwAI&ip=49.43.40.249&id=o-ACJVtrLBkCUx8brSgDFuAw58UxfKxs-D2E1UXKmFWQb_&itag=395&source=youtube&requiressl=yes&mh=Bh&mm=31%2C29&mn=sn-gwpa-cive%2Csn-gwpa-qxak&ms=au%2Crdu&mv=m&mvi=2&pl=22&gcr=in&initcwndbps=160000&vprv=1&mime=video%2Fmp4&gir=yes&clen=3391802&dur=300.680&lmt=1637221299765790&mt=1673452159&fvip=3&keepalive=yes&fexp=24007246&c=ANDROID&txp=5532434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cgcr%2Cvprv%2Cmime%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRgIhALKSkjRBuzweiCX3FIpvbXCaSdAj1S0nJJQUgBFZosyrAiEA16SIAskHTLMVxNGQtRq2XQbBPVZCsI3KYfWV81Vs-y4%3D&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIgIoRCe7Yk5uS4wvWplcXjGIsLkVXRAruEKmdzCsgneqQCIQCeSfA8p19j84KVfEczhxfqMywpZkJWwNwzEIWM1yvBfw%3D%3D",
            "mimeType":"video/mp4; codecs=\"av01.0.00M.08\"",
            "bitrate":146495,
            "width":392,
            "height":240,
            "initRange":{
               "start":"0",
               "end":"699"
            },
            "indexRange":{
               "start":"700",
               "end":"1439"
            },
            "lastModified":"1637221299765790",
            "contentLength":"3391802",
            "quality":"small",
            "fps":25,
            "qualityLabel":"240p",
            "projectionType":"RECTANGULAR",
            "averageBitrate":90243,
            "colorInfo":{
               "primaries":"COLOR_PRIMARIES_BT709",
               "transferCharacteristics":"COLOR_TRANSFER_CHARACTERISTICS_BT709",
               "matrixCoefficients":"COLOR_MATRIX_COEFFICIENTS_BT709"
            },
            "approxDurationMs":"300680"
         },
         {
            "itag":160,
            "url":"https://rr2---sn-gwpa-cive.googlevideo.com/videoplayback?expire=1673474248&ei=aNy-Y76qKaOj3LUPn5ebwAI&ip=49.43.40.249&id=o-ACJVtrLBkCUx8brSgDFuAw58UxfKxs-D2E1UXKmFWQb_&itag=160&source=youtube&requiressl=yes&mh=Bh&mm=31%2C29&mn=sn-gwpa-cive%2Csn-gwpa-qxak&ms=au%2Crdu&mv=m&mvi=2&pl=22&gcr=in&initcwndbps=160000&vprv=1&mime=video%2Fmp4&gir=yes&clen=1828219&dur=300.680&lmt=1637209250686783&mt=1673452159&fvip=3&keepalive=yes&fexp=24007246&c=ANDROID&txp=5535434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cgcr%2Cvprv%2Cmime%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRgIhAKHvfRx28UrGasuyA4nMclPyhLhm_EKmN9oC7jtz1mV3AiEAthhx_-fBpemNOR31ZgD8J2B7Lp7uPh9fb7_2ltt0UEw%3D&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIgIoRCe7Yk5uS4wvWplcXjGIsLkVXRAruEKmdzCsgneqQCIQCeSfA8p19j84KVfEczhxfqMywpZkJWwNwzEIWM1yvBfw%3D%3D",
            "mimeType":"video/mp4; codecs=\"avc1.4d400c\"",
            "bitrate":97059,
            "width":236,
            "height":144,
            "initRange":{
               "start":"0",
               "end":"739"
            },
            "indexRange":{
               "start":"740",
               "end":"1479"
            },
            "lastModified":"1637209250686783",
            "contentLength":"1828219",
            "quality":"tiny",
            "fps":25,
            "qualityLabel":"144p",
            "projectionType":"RECTANGULAR",
            "averageBitrate":48642,
            "approxDurationMs":"300680"
         },
         {
            "itag":278,
            "url":"https://rr2---sn-gwpa-cive.googlevideo.com/videoplayback?expire=1673474248&ei=aNy-Y76qKaOj3LUPn5ebwAI&ip=49.43.40.249&id=o-ACJVtrLBkCUx8brSgDFuAw58UxfKxs-D2E1UXKmFWQb_&itag=278&source=youtube&requiressl=yes&mh=Bh&mm=31%2C29&mn=sn-gwpa-cive%2Csn-gwpa-qxak&ms=au%2Crdu&mv=m&mvi=2&pl=22&gcr=in&initcwndbps=160000&vprv=1&mime=video%2Fwebm&gir=yes&clen=3297200&dur=300.680&lmt=1665687581573019&mt=1673452159&fvip=3&keepalive=yes&fexp=24007246&c=ANDROID&txp=5535434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cgcr%2Cvprv%2Cmime%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRAIgOFlQJshq9rVzPdQQZeoi2TamobTq5UAuoSn9-N58C-sCIGTZWTQ8CGifbEyMyEpV9KCVQmKSW0uLsJ2fLQ_kSJdI&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIgIoRCe7Yk5uS4wvWplcXjGIsLkVXRAruEKmdzCsgneqQCIQCeSfA8p19j84KVfEczhxfqMywpZkJWwNwzEIWM1yvBfw%3D%3D",
            "mimeType":"video/webm; codecs=\"vp9\"",
            "bitrate":97785,
            "width":236,
            "height":144,
            "initRange":{
               "start":"0",
               "end":"217"
            },
            "indexRange":{
               "start":"218",
               "end":"1176"
            },
            "lastModified":"1665687581573019",
            "contentLength":"3297200",
            "quality":"tiny",
            "fps":25,
            "qualityLabel":"144p",
            "projectionType":"RECTANGULAR",
            "averageBitrate":87726,
            "colorInfo":{
               "primaries":"COLOR_PRIMARIES_BT709",
               "transferCharacteristics":"COLOR_TRANSFER_CHARACTERISTICS_BT709",
               "matrixCoefficients":"COLOR_MATRIX_COEFFICIENTS_BT709"
            },
            "approxDurationMs":"300680"
         },
         {
            "itag":394,
            "url":"https://rr2---sn-gwpa-cive.googlevideo.com/videoplayback?expire=1673474248&ei=aNy-Y76qKaOj3LUPn5ebwAI&ip=49.43.40.249&id=o-ACJVtrLBkCUx8brSgDFuAw58UxfKxs-D2E1UXKmFWQb_&itag=394&source=youtube&requiressl=yes&mh=Bh&mm=31%2C29&mn=sn-gwpa-cive%2Csn-gwpa-qxak&ms=au%2Crdu&mv=m&mvi=2&pl=22&gcr=in&initcwndbps=160000&vprv=1&mime=video%2Fmp4&gir=yes&clen=2333267&dur=300.680&lmt=1637221153129919&mt=1673452159&fvip=3&keepalive=yes&fexp=24007246&c=ANDROID&txp=5532434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cgcr%2Cvprv%2Cmime%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRgIhAIKvUo8rf_a7wBHQVP2Uit86J-njxcjJ_FA359z1-NfhAiEAppPVdVjSHYUOeSADag_D4xUj4HCloL-GNhwLRVOiV8c%3D&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIgIoRCe7Yk5uS4wvWplcXjGIsLkVXRAruEKmdzCsgneqQCIQCeSfA8p19j84KVfEczhxfqMywpZkJWwNwzEIWM1yvBfw%3D%3D",
            "mimeType":"video/mp4; codecs=\"av01.0.00M.08\"",
            "bitrate":76901,
            "width":236,
            "height":144,
            "initRange":{
               "start":"0",
               "end":"699"
            },
            "indexRange":{
               "start":"700",
               "end":"1439"
            },
            "lastModified":"1637221153129919",
            "contentLength":"2333267",
            "quality":"tiny",
            "fps":25,
            "qualityLabel":"144p",
            "projectionType":"RECTANGULAR",
            "averageBitrate":62079,
            "colorInfo":{
               "primaries":"COLOR_PRIMARIES_BT709",
               "transferCharacteristics":"COLOR_TRANSFER_CHARACTERISTICS_BT709",
               "matrixCoefficients":"COLOR_MATRIX_COEFFICIENTS_BT709"
            },
            "approxDurationMs":"300680"
         },
         {
            "itag":139,
            "url":"https://rr2---sn-gwpa-cive.googlevideo.com/videoplayback?expire=1673474248&ei=aNy-Y76qKaOj3LUPn5ebwAI&ip=49.43.40.249&id=o-ACJVtrLBkCUx8brSgDFuAw58UxfKxs-D2E1UXKmFWQb_&itag=139&source=youtube&requiressl=yes&mh=Bh&mm=31%2C29&mn=sn-gwpa-cive%2Csn-gwpa-qxak&ms=au%2Crdu&mv=m&mvi=2&pl=22&gcr=in&initcwndbps=160000&vprv=1&mime=audio%2Fmp4&gir=yes&clen=1834966&dur=300.791&lmt=1637197819201236&mt=1673452159&fvip=3&keepalive=yes&fexp=24007246&c=ANDROID&txp=5532434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cgcr%2Cvprv%2Cmime%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRQIhAOQ8NKA2vj-nFRKpAJQdlWrSRJ3TfIrTJEWh5PKjgYRoAiA6Qf4Yaz4nOYid3ObBdtgq11MGj0KUbe3tmP4drk5m1w%3D%3D&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIgIoRCe7Yk5uS4wvWplcXjGIsLkVXRAruEKmdzCsgneqQCIQCeSfA8p19j84KVfEczhxfqMywpZkJWwNwzEIWM1yvBfw%3D%3D",
            "mimeType":"audio/mp4; codecs=\"mp4a.40.5\"",
            "bitrate":49914,
            "initRange":{
               "start":"0",
               "end":"640"
            },
            "indexRange":{
               "start":"641",
               "end":"1044"
            },
            "lastModified":"1637197819201236",
            "contentLength":"1834966",
            "quality":"tiny",
            "projectionType":"RECTANGULAR",
            "averageBitrate":48803,
            "audioQuality":"AUDIO_QUALITY_LOW",
            "approxDurationMs":"300791",
            "audioSampleRate":"22050",
            "audioChannels":2
         },
         {
            "itag":140,
            "url":"https://rr2---sn-gwpa-cive.googlevideo.com/videoplayback?expire=1673474248&ei=aNy-Y76qKaOj3LUPn5ebwAI&ip=49.43.40.249&id=o-ACJVtrLBkCUx8brSgDFuAw58UxfKxs-D2E1UXKmFWQb_&itag=140&source=youtube&requiressl=yes&mh=Bh&mm=31%2C29&mn=sn-gwpa-cive%2Csn-gwpa-qxak&ms=au%2Crdu&mv=m&mvi=2&pl=22&gcr=in&initcwndbps=160000&vprv=1&mime=audio%2Fmp4&gir=yes&clen=4867985&dur=300.744&lmt=1637197818916001&mt=1673452159&fvip=3&keepalive=yes&fexp=24007246&c=ANDROID&txp=5532434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cgcr%2Cvprv%2Cmime%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRQIhALAysRzPRKiehrAvuJfTEIrplulT2lh-pC2hN4RystnLAiBwtFtNkH9nc_A5bAthE3z3hrAM9gh4sTHYIuQ4pgH5Ow%3D%3D&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIgIoRCe7Yk5uS4wvWplcXjGIsLkVXRAruEKmdzCsgneqQCIQCeSfA8p19j84KVfEczhxfqMywpZkJWwNwzEIWM1yvBfw%3D%3D",
            "mimeType":"audio/mp4; codecs=\"mp4a.40.2\"",
            "bitrate":130709,
            "initRange":{
               "start":"0",
               "end":"631"
            },
            "indexRange":{
               "start":"632",
               "end":"1035"
            },
            "lastModified":"1637197818916001",
            "contentLength":"4867985",
            "quality":"tiny",
            "projectionType":"RECTANGULAR",
            "averageBitrate":129491,
            "highReplication":True,
            "audioQuality":"AUDIO_QUALITY_MEDIUM",
            "approxDurationMs":"300744",
            "audioSampleRate":"44100",
            "audioChannels":2
         },
         {
            "itag":249,
            "url":"https://rr2---sn-gwpa-cive.googlevideo.com/videoplayback?expire=1673474248&ei=aNy-Y76qKaOj3LUPn5ebwAI&ip=49.43.40.249&id=o-ACJVtrLBkCUx8brSgDFuAw58UxfKxs-D2E1UXKmFWQb_&itag=249&source=youtube&requiressl=yes&mh=Bh&mm=31%2C29&mn=sn-gwpa-cive%2Csn-gwpa-qxak&ms=au%2Crdu&mv=m&mvi=2&pl=22&gcr=in&initcwndbps=160000&vprv=1&mime=audio%2Fwebm&gir=yes&clen=1943820&dur=300.701&lmt=1637197778661693&mt=1673452159&fvip=3&keepalive=yes&fexp=24007246&c=ANDROID&txp=5532434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cgcr%2Cvprv%2Cmime%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRQIhAM-V6g544DeDbd8IOYWSWGVN3HW87NCsuVdF3m34VCp6AiAIC2ss11_fqSvsdD9luuZ-90jDNWKsevqkt2KR4cEFbg%3D%3D&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIgIoRCe7Yk5uS4wvWplcXjGIsLkVXRAruEKmdzCsgneqQCIQCeSfA8p19j84KVfEczhxfqMywpZkJWwNwzEIWM1yvBfw%3D%3D",
            "mimeType":"audio/webm; codecs=\"opus\"",
            "bitrate":59286,
            "initRange":{
               "start":"0",
               "end":"265"
            },
            "indexRange":{
               "start":"266",
               "end":"789"
            },
            "lastModified":"1637197778661693",
            "contentLength":"1943820",
            "quality":"tiny",
            "projectionType":"RECTANGULAR",
            "averageBitrate":51714,
            "audioQuality":"AUDIO_QUALITY_LOW",
            "approxDurationMs":"300701",
            "audioSampleRate":"48000",
            "audioChannels":2
         },
         {
            "itag":250,
            "url":"https://rr2---sn-gwpa-cive.googlevideo.com/videoplayback?expire=1673474248&ei=aNy-Y76qKaOj3LUPn5ebwAI&ip=49.43.40.249&id=o-ACJVtrLBkCUx8brSgDFuAw58UxfKxs-D2E1UXKmFWQb_&itag=250&source=youtube&requiressl=yes&mh=Bh&mm=31%2C29&mn=sn-gwpa-cive%2Csn-gwpa-qxak&ms=au%2Crdu&mv=m&mvi=2&pl=22&gcr=in&initcwndbps=160000&vprv=1&mime=audio%2Fwebm&gir=yes&clen=2569089&dur=300.701&lmt=1637197778609968&mt=1673452159&fvip=3&keepalive=yes&fexp=24007246&c=ANDROID&txp=5532434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cgcr%2Cvprv%2Cmime%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRAIgMdlKCq6GUspKnl9FpsY0WBl4xqo-AeqXosnwMW7Z5nACIAYqCtixF18xEvhqpiyVpj_bUbTsd0PPpjzc9qC9essE&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIgIoRCe7Yk5uS4wvWplcXjGIsLkVXRAruEKmdzCsgneqQCIQCeSfA8p19j84KVfEczhxfqMywpZkJWwNwzEIWM1yvBfw%3D%3D",
            "mimeType":"audio/webm; codecs=\"opus\"",
            "bitrate":77021,
            "initRange":{
               "start":"0",
               "end":"265"
            },
            "indexRange":{
               "start":"266",
               "end":"789"
            },
            "lastModified":"1637197778609968",
            "contentLength":"2569089",
            "quality":"tiny",
            "projectionType":"RECTANGULAR",
            "averageBitrate":68349,
            "audioQuality":"AUDIO_QUALITY_LOW",
            "approxDurationMs":"300701",
            "audioSampleRate":"48000",
            "audioChannels":2
         },
         {
            "itag":251,
            "url":"https://rr2---sn-gwpa-cive.googlevideo.com/videoplayback?expire=1673474248&ei=aNy-Y76qKaOj3LUPn5ebwAI&ip=49.43.40.249&id=o-ACJVtrLBkCUx8brSgDFuAw58UxfKxs-D2E1UXKmFWQb_&itag=251&source=youtube&requiressl=yes&mh=Bh&mm=31%2C29&mn=sn-gwpa-cive%2Csn-gwpa-qxak&ms=au%2Crdu&mv=m&mvi=2&pl=22&gcr=in&initcwndbps=160000&vprv=1&mime=audio%2Fwebm&gir=yes&clen=5057217&dur=300.701&lmt=1637197829639722&mt=1673452159&fvip=3&keepalive=yes&fexp=24007246&c=ANDROID&txp=5532434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cgcr%2Cvprv%2Cmime%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRQIhANts82YbEyjUzrNwO1cuQkFnDb2VaFHZTY-3CZwRr2B8AiAN1OAGVTBU1xbXdP84otCkI0UBXukdtgdNI3wx-KKR-g%3D%3D&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AG3C_xAwRQIgIoRCe7Yk5uS4wvWplcXjGIsLkVXRAruEKmdzCsgneqQCIQCeSfA8p19j84KVfEczhxfqMywpZkJWwNwzEIWM1yvBfw%3D%3D",
            "mimeType":"audio/webm; codecs=\"opus\"",
            "bitrate":146149,
            "initRange":{
               "start":"0",
               "end":"265"
            },
            "indexRange":{
               "start":"266",
               "end":"789"
            },
            "lastModified":"1637197829639722",
            "contentLength":"5057217",
            "quality":"tiny",
            "projectionType":"RECTANGULAR",
            "averageBitrate":134544,
            "audioQuality":"AUDIO_QUALITY_MEDIUM",
            "approxDurationMs":"300701",
            "audioSampleRate":"48000",
            "audioChannels":2
         }
      ]
   }
}

def sind():
    print(len(dat['thumbnails']))
    thumbnailsSize = []

    for x in range(len(dat['thumbnails'])):
        
        if '.jpg' in dat['thumbnails'][x]['url']:
            refSzie = dat['thumbnails'][x]['width']  #dat['thumbnails'][x]['width'] + dat['thumbnails'][x]['height']
            thumbnailsSize.append(refSzie)

        else:
            thumbnailsSize.append(0)
#
    
    print(thumbnailsSize)
    #return thumbnailsSize.index(max(thumbnailsSize))
            
            
    

    
   

#print((dat['thumbnails'][sind()]['url']).split('?',1)[0])

sind()