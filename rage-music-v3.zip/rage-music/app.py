from flask import Flask, render_template,request,redirect,url_for,send_from_directory,make_response
import json
import requests

import downloadMusic as dlp
import mineRequestedData as mrd
import os
import generateStaticPage as gsp
from flask_ngrok import run_with_ngrok

import encryptData

app = Flask(__name__)
#run_with_ngrok(app)


@app.route('/requests_for_song')
def requestSong():
	return None

'''
@app.route('/player')
def player():
	parser = mrd.Search('better call saul theme')
	parserFinal = parser.processJson(True)
	print(parserFinal[0])
	return render_template('player.html',
	musicThumbnail = parserFinal[3],
	musicName = parserFinal[0],
	singerName = parserFinal[4],
	musicUrl = parserFinal[6]
	)
	'''



def frontPageContent():
	topMusic = ["careless whisper","tourne"]

@app.route('/')
def home():
	#print(request.host_url)

	


	return render_template('index.html')



 

@app.route('/preLoadedPages/<id>', methods=['GET'])
def preloaded(id):
	print(id)
	return(render_template(f"preLoadedPages/{id}.html"))


global saveIdFromlPTosrch

#-------------------------------------------------------------------
#Main Function : search - download audio - build page - return id 
#-------------------------------------------------------------------
def loadPlayer(mname):
	print("\033[32;1m [+] Seaching - Downloading - Generating Page")
	parser = mrd.Search(mname)
	parserFinal = parser.processJson(True)
	parseYtdlpAudio =  request.host_url + str('static/audio/') + str(parserFinal[1]) + str('.mp3')
	
	dlp.downloadAudioDlp(parserFinal[1])

	saveDynamic = gsp.buildPage(parserFinal[3],parserFinal[0],parserFinal[4],parseYtdlpAudio,parserFinal[1])
	saveDynamic.build()

	'''
	return render_template(f'player.html',
	musicThumbnail = parserFinal[3]
	musicName = parserFinal[0]
	singerName = parserFinal[4]
	musicUrl = parserFinal[6]
	)
	'''
	
	return parserFinal[1]


@app.route('/process/', methods=['GET',"POST"])
def processUserInputFromIndex():
	print("\033[33;1m [++] Redirecting User Search To Player Through ?playid= ")
	if request.method == "POST":
		qName = request.form.get("searchmusic")
		print(qName)

	
	return redirect(f'/player?playid={qName}')
	


@app.route('/player/')
def srch():
	print("\033[32;1m [+++] Routeing To Player")
	

	musicName = request.args.get("playid", default=1, type=str)

	if musicName == "testserver":
		print("\033[33;1m [*++] Welcome To TestServer")
		print("[*] Running TestServer")
		return render_template("player.html")

	else:
		# musicName = request.form.get("searchmusic")
		print(musicName)

		saveIdFromlPTosrch = loadPlayer(musicName)

		return preloaded(saveIdFromlPTosrch)


'''


@app.route('/player/')
def buildDynamic():

	if request.args.get('playid', default = 1, type = str) == '':
		print("no")
		parser = mrd.Search('No fet')
		parserFinal = parser.processJson(True)
	
		saveDynamic = gsp.buildPage(parserFinal[3],parserFinal[0],parserFinal[4],parserFinal[6],parserFinal[1])
		saveDynamic.build()

		#return render_template(f'player.html',
		#musicThumbnail = parserFinal[3]
		#musicName = parserFinal[0]
		#singerName = parserFinal[4]
		#musicUrl = parserFinal[6]
		#)
		return preloaded(request.args.get('playid', default = 1, type = str))

	if os.path.exists('templates/preLoadedPages/'+request.args.get('playid', default = 1, type = str)+'.html'):
		print("yes")
		return preloaded(request.args.get('playid', default = 1, type = str))


	else:
		print("no")
		parser = mrd.Search('BX0lKSa_PT')
		parserFinal = parser.processJson(True)
	
		saveDynamic = gsp.buildPage(parserFinal[3],parserFinal[0],parserFinal[4],parserFinal[6],parserFinal[1])
		saveDynamic.build()

		#return render_template(f'player.html',
		#musicThumbnail = parserFinal[3]
		#musicName = parserFinal[0]
		#singerName = parserFinal[4]
		#musicUrl = parserFinal[6]
		#)
		return preloaded(request.args.get('playid', default = 1, type = str))
		


	
	
	#page = request.args.get('shareid', default = 1, type = str)
	#return str(page)'''

@app.route('/cookie')  
def cookie():  
	res = make_response(render_template('index.html'))  
	res.set_cookie('foo','username123456789',max_age=31_556_952)
	
	print(request.cookies.get('foo'))

	return res

@app.route('/notifyEmail', methods=['GET',"POST"])
def saveEmailForUserNotification():
	if request.method == 'POST':
		eml = request.form.get('notifyemail')
		emlenc = (encryptData.main(eml,'rage','encrypt'))
		print(emlenc)
		print(encryptData.main(emlenc,'rage','decrypt'))
		print(request.headers.get('User-Agent'))

		# JSON random id -> user-agent -> user-email  -> time



		
	return home()

if __name__ == '__main__':
  
	app.run(host="192.168.29.171",port=5500) #(debug=True,host="127.0.0.1",port="8000")
	
	
