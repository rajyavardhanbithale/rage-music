
url = 'http://testing.com/book.html?default=<script>alert(document.cookie)</script>'
import re
 
pattern = "^https:\/\/[0-9A-z.]+.[0-9A-z.]+.[a-z]+$"
result = re.match(pattern, url)

if result: 
    print(result)
else:
    print("Invalid URL")

#print(is_safe_url("http://testing.com/book.html?default=<script>alert(document.cookie)</script>"))

#print(urllib.parse.urlparse('http://testing.com/book.html?default=<script>alert(document.cookie)</script>'))